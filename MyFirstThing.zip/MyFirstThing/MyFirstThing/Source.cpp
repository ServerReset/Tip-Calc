
#include <iostream>

#include <string>

#include <limits>

#include <iomanip>

using namespace std;

void NextFirst()
{
	
	cout << endl << "Press Enter to Continue . . ." << endl;

	cin.ignore(std::numeric_limits<streamsize>::max(), '\n');

	for (int a = 0; a < 28; a++)
	{

	cout << endl;

	}

}

void Next1()
{
		for (int a = 0; a < 31; a++)
	{

		cout << endl;

	}
		
		cout << endl << "Press Enter to Continue . . ." << endl;

	cin.ignore(std::numeric_limits<streamsize>::max(), '\n');

}

void Next2()
{
	
	cout << endl << "Press Enter to Continue . . ." << endl;

	cin.ignore(std::numeric_limits<streamsize>::max(), '\n');


	for (int a = 0; a < 31; a++)
	{

		cout << endl;

	}
}

void Meals()
{

int Ammount;

string pNames[50];

int pMoney[50];

double pTip[50];

int thing = 0;

int thing2 = 0;

int thing3 = 0;

int PersonNumber = 1;

double PersonMoney = 1;

int PersonTip = 1;

cout << "How Many People are in your Party? (Max 50)" << endl;

	cin >> Ammount;

		while (thing == 0)
		{
			Next2();

			cout << "Enter Person " << PersonNumber << "'s Name Here" << endl;

			cin >> pNames[PersonNumber--];

			cout << endl;

			PersonNumber++;

			if (PersonNumber == Ammount)
			{

				thing = 1;

			}

			PersonNumber++;

		}
		cout << "exit inner while loop" << endl; 

		PersonNumber = 1;

			while (thing2 == 0)
			{

				Next2();

				cout << "Enter Amount Person " << PersonNumber << " Owes" << endl;

				cin >> pMoney[PersonNumber--];

				cout << endl;

				PersonNumber++;

				if (PersonNumber == Ammount)
				{

					thing2 = 1;
					cout << "enter personnum == amount" << endl;
				}

				PersonNumber++;
				cout << "exit if statment " << endl;

			}
			cout << "exit inner while loop" << endl; 

	PersonNumber = 1;

	while (thing3 == 0)
	{

		Next2();

		cout << "Enter Tip Percent " << pNames[PersonNumber] << " Would Like To Add" << endl;

		cin >> pTip[PersonNumber--];

		pTip[PersonNumber] /= 100;

		pTip[PersonNumber] += 1;

		PersonMoney *= pTip[PersonNumber];

		PersonNumber++;

		cout << endl;

		if (PersonNumber == Ammount)
		{

			thing3 = 1;

		}

		PersonNumber++;

	}

	PersonNumber = 1;

	while (PersonNumber < Ammount++)
	{

		cout << "This is what " << pNames[PersonNumber--] << "Owes With Tip" << endl;

		cout << endl;

		PersonNumber++;

		cout << pMoney[PersonNumber];

		PersonNumber++;

	}

	cout << endl;

}
	string People = "No";

	string Again = "Yes";

int main()
{

	while(Again == "Yes" || Again == "yes" || Again == "y" || Again == "Y")
	{
		cout << setprecision(4);

		cout << "Welcome to the tip calculator" << endl;

		NextFirst();

		Meals();

	}















































































































































































































}