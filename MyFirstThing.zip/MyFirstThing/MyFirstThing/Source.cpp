
#include <iostream>

#include <string>

#include <limits>

#include <iomanip>

using namespace std;

void NextFirst()
{
	
	cout << endl << "Press Enter to Continue . . ." << endl;

	cin.ignore(std::numeric_limits<streamsize>::max(), '\n');

	for (int a = 0; a < 28; a++)
	{

	cout << endl;

	}

}

void Next2()
{
	
	cout << endl << "Press Enter to Continue . . ." << endl;

	cin.ignore(std::numeric_limits<streamsize>::max(), '\n');


	for (int a = 0; a < 31; a++)
	{

		cout << endl;

	}
}

void Meals()
{

cout << setprecision(4);

int Ammount;

string pNames[250];

double pMoney[250];

double pTip[250];

int thing = 0;

int thing2 = 0;

int thing3 = 0;

int PersonNumber = 1;

double PersonMoney = 1;

int PersonTip = 1;

cout << "How Many People are in your Party? (Max 250)" << endl;

	cin >> Ammount;

		while (thing == 0)
		{
			Next2();

			cout << "Enter Person " << PersonNumber << "'s Name Here" << endl;

			cin >> pNames[PersonNumber--];

			cout << endl;

			PersonNumber++;

			if (PersonNumber == Ammount)
			{

				thing = 1;

			}

			PersonNumber++;

		} 

		PersonNumber = 1;

			while (thing2 == 0)
			{

				Next2();

				cout << "Enter Amount " << pNames[PersonNumber--] << " Owes" << endl;

				PersonNumber++;

				cout << "$";

				cin >> pMoney[PersonNumber--];

				cout << endl;

				PersonNumber++;

				if (PersonNumber == Ammount)
				{

					thing2 = 1;

				}

				PersonNumber++;

			} 

	PersonNumber = 1;

	while (thing3 == 0)
	{

		Next2();

		cout << "Enter Tip Percent " << pNames[PersonNumber] << " Would Like To Add" << endl;

		PersonMoney = pMoney[PersonNumber--];

		cout << "%";

		cin >> pTip[PersonNumber];

		pTip[PersonNumber] /= 100;

		pTip[PersonNumber] += 1;

		cout << pTip[PersonNumber] << endl;

		PersonMoney *= pTip[PersonNumber];

		pMoney[PersonNumber] = PersonMoney;

		cout << PersonMoney << endl;

		PersonNumber++;

		cout << endl;

		if (PersonNumber == Ammount)
		{

			thing3 = 1;

		}

		PersonNumber++;

	}

	PersonNumber = 1;

	Next2();

	while (PersonNumber <= Ammount)
	{
		
		cout << "This is what " << pNames[PersonNumber--] << " Owes With Tip" << endl;

		cout << endl;

		cout << "$" << pMoney[PersonNumber] << endl;

		cout << endl;

		PersonNumber++;

		PersonNumber++;

	}

	cout << endl;

}
	string People = "No";

	string Again = "Yes";

int main()
{

	while(Again == "Yes" || Again == "yes" || Again == "y" || Again == "Y")
	{
		
		cout << "Welcome to the tip calculator" << endl;

		NextFirst();

		Meals();

		cout << "Do You Want To Calculate Again?" << endl;

		cin >> Again;

		cout << endl;

	}















































































































































































































}